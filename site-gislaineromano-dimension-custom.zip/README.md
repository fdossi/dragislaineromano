# Site — Dra. Gislaine Romano (Tema: HTML5 UP Dimension)

Pronto para **GitHub Pages**.

## Publicação
1. Crie o repositório (ex.: `gislaineromano-site`).
2. Suba todos os arquivos (incluindo `.nojekyll`).
3. Em **Settings → Pages**, selecione branch `main` e pasta `/root`.

### Ajustes rápidos
- Substitua `username` e `repo` em:
  - `robots.txt`
  - `sitemap.xml`
  - `index.html` (campo `_next` do formulário)
- Para domínio próprio, crie `CNAME` com o domínio e ajuste as mesmas URLs.

### Formulário
Usa **FormSubmit** com destino `contato@nutricao.pet`. Para trocar o e-mail, edite o `action` do `<form>`.

### Google Maps
Troque `AIzaSyD-PLACEHOLDER` por uma API key do Google Maps para exibir o mapa embutido.


---

## Publicação com domínio próprio
- Repositório: **fdossi/dragislaineromano**
- Domínio: **www.dragislaineromano.com.br**

Passos:
1. Faça upload de todos os arquivos na branch `main` do repositório `dragislaineromano`.
2. Em **Settings → Pages**, selecione `Build and deployment → Source: Deploy from a branch`, depois `Branch: main / root`.
3. Em **Settings → Pages → Custom domain**, informe **www.dragislaineromano.com.br**. O arquivo `CNAME` já está incluído.
4. No seu provedor de DNS, aponte:
   - `A` (apex): 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
   - (opcional) `AAAA` (IPv6): 2606:50c0:8000::153, 2606:50c0:8001::153, 2606:50c0:8002::153, 2606:50c0:8003::153
   - `CNAME` para `www` → `fdossi.github.io` **ou** use somente `www.dragislaineromano.com.br` como domínio principal (com redirecionamento do apex para `www`).

Após a propagação do DNS, acione **Enforce HTTPS** em Pages.
